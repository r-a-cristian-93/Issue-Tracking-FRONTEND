document.addEventListener("DOMContentLoaded", function(){	
    getDepartments(setOptions, document.filter.department);
    getStatus(setOptions, document.filter.status);
    filterManageTickets();
})


function filterManageTickets() {
	var request = new XMLHttpRequest;
	var department = document.filter.department.value;
	var status = document.filter.status.value;
	
	request.onreadystatechange = function() {
		if(this.readyState==4 && this.status==200){
			var jsonTickets = JSON.parse(this.responseText);
			
			document.filter.childNodes[7].innerHTML = 'Found ' + jsonTickets.length + ' tickets.'
				
			var divTickets = document.getElementsByClassName('ticket');
			var length = divTickets.length;
			for(i=0; i<length; i++) {
				divTickets[0].remove();
			}
			
			for(i=0; i<jsonTickets.length; i++) {
				var ticket = buildTicket(jsonTickets[i]);

				document.getElementById('tickets').appendChild(ticket);
			}
		}
	}
	request.open('GET', '/helpdesk/owner/superfilter?department='+department+'&status='+status);
	request.send();
}

function buildTicket(jsonTicket) {
	var status = jsonTicket.status;

	var divTopLeft = document.createElement('div');
	divTopLeft.className='ticket-top-left';
	divTopLeft.appendChild(makeIdLabel(jsonTicket));
	divTopLeft.appendChild(makeStatusLabel(jsonTicket));
	
	var divTopRight = document.createElement('div');
	divTopRight.className='ticket-top-right';
	divTopRight.appendChild(makeIssueParagraph(jsonTicket));
	
	var divTopHalf = document.createElement('div');
	divTopHalf.className='ticket-top-half';
	divTopHalf.appendChild(divTopLeft);
	divTopHalf.appendChild(divTopRight);
	
	var divBottomHalf = document.createElement('div');
	divBottomHalf.className='ticket-bottom-half';
	divBottomHalf.appendChild(makeAssignOption(jsonTicket));
	if(status=='Open' || status=='Pending'){
		divBottomHalf.appendChild(makeCloseOption(jsonTicket));
	}
	divBottomHalf.appendChild(makeDeleteOption(jsonTicket));
	divBottomHalf.appendChild(makeTicketCol('Opened by', jsonTicket.openedBy));
	
	if(jsonTicket.assignedTo) {
		divBottomHalf.appendChild(makeTicketCol('Assigned to', jsonTicket.assignedTo));
	}
	if(jsonTicket.closedBy) {
		divBottomHalf.appendChild(makeTicketCol('Closed by', jsonTicket.closedBy));
	}	
	
	var ticket=document.createElement('div');
	ticket.className='ticket';
	ticket.setAttribute('id', jsonTicket.id);
	ticket.append(divTopHalf);
	ticket.append(divBottomHalf);
	
	return ticket;
}


