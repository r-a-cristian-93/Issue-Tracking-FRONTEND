import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import org.json.*;

@WebServlet(value="/admin/getticket")
public class GetTicketController extends HttpServlet {
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		int id = Integer.valueOf(request.getParameter("id"));
			
		JSONObject jsonTicket;
		try {
			TicketBean ticket = Helper.getTicket(id);
			jsonTicket = new JSONObject(ticket);
		}
		catch (SQLException e) {
			jsonTicket = new JSONObject().put("error", e.getMessage());
		}
		response.setContentType("application/json");
		response.getWriter().print(jsonTicket);		
	}
}
