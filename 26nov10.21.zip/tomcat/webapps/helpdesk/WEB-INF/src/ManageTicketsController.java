import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import org.json.*;

@WebServlet(value="/moderator/filtermanagetickets")
public class ManageTicketsController extends HttpServlet {
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String role = ((UserBean) request.getAttribute("user_bean")).getRole();
		String moderatorDepartment = ((UserBean) request.getAttribute("user_bean")).getDepartment();
		String filterDepartment=request.getParameter("department");
		String filterStatus=request.getParameter("status");
			
		JSONArray jsonTickets = new JSONArray();
		try {
			ArrayList<TicketBean> tickets = new ArrayList<>();
			if (role.equals("Owner")) {
				tickets = Helper.getTickets(filterDepartment, filterStatus);
			}
			else {
				tickets = Helper.getTickets(moderatorDepartment, filterDepartment, filterStatus);
			}
			tickets.forEach(e->jsonTickets.put(new JSONObject(e)));
		}
		catch (SQLException e) {
			jsonTickets.put(e.getMessage());
		}
		response.setContentType("application/json");
		response.getWriter().print(jsonTickets);		
	}
}
