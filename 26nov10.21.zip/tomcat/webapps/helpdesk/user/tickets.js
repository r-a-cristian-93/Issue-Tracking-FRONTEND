function myTickets(status) {
	var request = new XMLHttpRequest;
	request.onreadystatechange = function() {
		if(this.readyState==4 && this.status==200){
			var divTickets = document.getElementsByClassName('ticket');
			var length = divTickets.length;
			for(i=0; i<length; i++) {
				divTickets[0].remove();
			}			
			
			var jsonTickets = JSON.parse(this.responseText);
			for(i=0; i<jsonTickets.length; i++) {
				var status = jsonTickets[i].status;

				var divTopLeft = document.createElement('div');
				divTopLeft.className='ticket-top-left';
				divTopLeft.appendChild(makeIdLabel(jsonTickets[i]));
				divTopLeft.appendChild(makeStatusLabel(jsonTickets[i]));
				
				var divTopRight = document.createElement('div');
				divTopRight.className='ticket-top-right';
				divTopRight.appendChild(makeIssueParagraph(jsonTickets[i]));
				
				var divTopHalf = document.createElement('div');
				divTopHalf.className='ticket-top-half';
				divTopHalf.appendChild(divTopLeft);
				divTopHalf.appendChild(divTopRight);
				
				var divBottomHalf = document.createElement('div');
				divBottomHalf.className='ticket-bottom-half';

				if(jsonTickets[i].assignedTo) {
					divBottomHalf.appendChild(makeTicketCol('Assigned to', jsonTickets[i].assignedTo));
				}
				else {
					divBottomHalf.appendChild(makeTicketCol('Assigned to', 'Not assigned yet'));
				}
				if(jsonTickets[i].closedBy) {
					divBottomHalf.appendChild(makeTicketCol('Closed by', jsonTickets[i].closedBy));
				}	
				
				/*
				divBottomHalf.appendChild(makeDepartmentLabel(jsonTickets[i]));
				*/
				
				var ticket=document.createElement('div');
				ticket.className='ticket';
				ticket.append(divTopHalf);
				ticket.append(divBottomHalf);

				document.getElementById('tickets').appendChild(ticket);
			}
		}
	}
	request.open('GET', '/helpdesk/user/my-tickets?status='+status);
	request.send();
}
	
function makeIdLabel(jsonTicket) {
	var text=document.createTextNode('#'+jsonTicket.id);
	var h5=document.createElement('h5');
	h5.className='ticket-id';
	h5.appendChild(text);
	return h5;
}

function makeStatusLabel(jsonTicket) {
	var text=document.createTextNode(jsonTicket.status.toUpperCase());
	var h5=document.createElement('h5');
	h5.className=jsonTicket.status.toLowerCase();
	h5.appendChild(text);
	return h5;
}

function makeDepartmentLabel(jsonTicket) {
	var text=document.createTextNode(jsonTicket.department);
	var h5=document.createElement('h5');
	h5.className=jsonTicket.status.toLowerCase();
	h5.appendChild(text);
	return h5;
}

function makeAssignedLabel(jsonTicket) {
	var assignedTo = jsonTicket.assignedTo;
	var text = document.createTextNode(assignedTo);
	var a = document.createElement('a');
	a.className=jsonTicket.status.toLowerCase();
	a.setAttribute('href', 'mailto:'+assignedTo);
	a.appendChild(text);
	var h5 = document.createElement('h5');
	h5.className=jsonTicket.status.toLowerCase();
	h5.appendChild(document.createTextNode('Assigned to: '));
	h5.appendChild(a);
	return h5;
}


function makeClosedLabel(jsonTicket) {
	var closedBy = jsonTicket.closedBy;
	var text = document.createTextNode(closedBy);
	var a = document.createElement('a');
	a.className=jsonTicket.status.toLowerCase();
	a.setAttribute('href', 'mailto:'+closedBy);
	a.appendChild(text);
	var h5 = document.createElement('h5');
	h5.className=jsonTicket.status.toLowerCase();
	h5.appendChild(document.createTextNode('Closed by: '));
	h5.appendChild(a);
	return h5;
}

function makeIssueParagraph(jsonTicket) {
	var summary = document.createElement('div');
	summary.className = 'ticket-summary';
	summary.innerHTML=jsonTicket.summary;
	var issue = document.createElement('p');
	issue.innerHTML = jsonTicket.issue;
	var div = document.createElement('div');
	div.className='ticket-issue';
	div.appendChild(summary);
	div.appendChild(issue);
	return div;
}

function makeTicketCol(title, value) {
	var letter=document.createTextNode(value[0].toUpperCase());
	var divLogo = document.createElement('div');
	divLogo.className='ticket-logo';
	divLogo.appendChild(letter);
	
	var divTitle = document.createElement('div');
	divTitle.className = 'ticket-col-title';
	divTitle.appendChild(document.createTextNode(title));
	
	var a = document.createElement('a');
	a.className='ticket-col-value';
	a.setAttribute('href', 'mailto:'+value);
	a.appendChild(document.createTextNode(value));
	
	var divInfo = document.createElement('div');
	divInfo.className = 'ticket-col-info';
	divInfo.appendChild(divTitle);
	divInfo.appendChild(a);	
	
	var divCol = document.createElement('div');
	divCol.className='ticket-col';
	divCol.appendChild(divLogo);
	divCol.appendChild(divInfo);

	return divCol;
}
