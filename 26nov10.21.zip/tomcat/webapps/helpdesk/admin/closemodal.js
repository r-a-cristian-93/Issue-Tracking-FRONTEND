function showCloseModal(ticketId) {
	document.closeTicketForm.ticketId.value = ticketId;
	document.getElementById("closeId").innerHTML = ticketId;
	document.getElementById("closeModal").style.display="block";
}

function hideCloseModal() {
	document.getElementById("closeModal").style.display="none";
}

function closeTicket() {
	var ticketId = document.closeTicketForm.ticketId.value;
	var status = document.closeTicketForm.status.value;
	
	var request = new XMLHttpRequest();
	request.onreadystatechange = function() {
		if(this.readyState==4 && this.status==200) {
			hideCloseModal();
			refreshTicket(ticketId);
		}		
	}
	
	request.open('GET', '/helpdesk/admin/closeticket?ticketId='+ticketId+'&status='+status);
	request.send();
}


function makeCloseOption(jsonTicket) {
	var img = document.createElement('img');
	img.className='option-img';
	img.setAttribute('src', '../icons/close.png');
	var div = document.createElement('div');
	div.className='option';
	div.setAttribute('onclick', 'showCloseModal(' + jsonTicket.id + ')');
	div.appendChild(img);
	return div;
}

function refreshTicket(ticketId) {	
	var request = new XMLHttpRequest();
	request.onreadystatechange = function () {
		if(this.readyState==4 && this.status==200) {
			jsonTicket = JSON.parse(this.responseText);
			var ticket = buildTicket(jsonTicket);
			var old = document.getElementById(ticketId);
			old.parentNode.replaceChild(ticket, old);
		}
	}
	request.open('GET', '/helpdesk/admin/getticket?id='+ ticketId);
	request.send();
}
