docker stop hd_database
docker rm hd_database
docker build -t hd_database .
