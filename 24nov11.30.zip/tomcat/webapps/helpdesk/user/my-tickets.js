document.addEventListener("DOMContentLoaded", function(){	
    myTickets();
})
