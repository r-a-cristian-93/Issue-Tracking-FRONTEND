import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import org.json.*;

@WebServlet(value="/owner/superfilter")
public class SuperTicketsController extends HttpServlet {
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String filterDepartment=request.getParameter("department");
		String filterStatus=request.getParameter("status");
			
		JSONArray jsonTickets = new JSONArray();
		try {
			ArrayList<TicketBean> tickets = Helper.getTickets(filterDepartment, filterStatus);
			tickets.forEach(e->jsonTickets.put(new JSONObject(e)));
		}
		catch (SQLException e) {
			jsonTickets.put(e.getMessage());
		}
		response.setContentType("application/json");
		response.getWriter().print(jsonTickets);		
	}
}
