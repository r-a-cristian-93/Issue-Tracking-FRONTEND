document.addEventListener("DOMContentLoaded", function(){	
    getDepartments(setOptions, document.filter.department);
    getStatus(setOptions, document.filter.status);
    filterManageTickets();
})

function filterManageTickets() {
	var request = new XMLHttpRequest;
	var department = document.filter.department.value;
	var status = document.filter.status.value;
	
	request.onreadystatechange = function() {
		if(this.readyState==4 && this.status==200){
			var jsonTickets = JSON.parse(this.responseText);
			
			document.filter.childNodes[7].innerHTML = 'Found ' + jsonTickets.length + ' tickets.'
				
			var divTickets = document.getElementsByClassName('ticket');
			var length = divTickets.length;
			for(i=0; i<length; i++) {
				divTickets[0].remove();
			}
			
			for(i=0; i<jsonTickets.length; i++) {
				var status = jsonTickets[i].status;

				var divTopLeft = document.createElement('div');
				divTopLeft.className='ticket-top-left';
				divTopLeft.appendChild(makeIdLabel(jsonTickets[i]));
				divTopLeft.appendChild(makeStatusLabel(jsonTickets[i]));
				
				var divTopRight = document.createElement('div');
				divTopRight.className='ticket-top-right';
				divTopRight.appendChild(makeIssueParagraph(jsonTickets[i]));
				
				var divTopHalf = document.createElement('div');
				divTopHalf.className='ticket-top-half';
				divTopHalf.appendChild(divTopLeft);
				divTopHalf.appendChild(divTopRight);
				
				var divBottomHalf = document.createElement('div');
				divBottomHalf.className='ticket-bottom-half';
				divBottomHalf.appendChild(makeAssignOption(jsonTickets[i]));
				if(status=='Open' || status=='Pending'){
					divBottomHalf.appendChild(makeCloseOption(jsonTickets[i]));
				}
				divBottomHalf.appendChild(makeTicketCol('Opened by', jsonTickets[i].openedBy));
				
				if(jsonTickets[i].assignedTo) {
					divBottomHalf.appendChild(makeTicketCol('Assigned to', jsonTickets[i].assignedTo));
				}
				if(jsonTickets[i].closedBy) {
					divBottomHalf.appendChild(makeTicketCol('Closed by', jsonTickets[i].closedBy));
				}	
				
				var ticket=document.createElement('div');
				ticket.className='ticket';
				ticket.append(divTopHalf);
				ticket.append(divBottomHalf);

				document.getElementById('tickets').appendChild(ticket);
			}
		}
	}
	request.open('GET', '/helpdesk/moderator/filtermanagetickets?department='+department+'&status='+status);
	request.send();
}
