document.addEventListener("DOMContentLoaded", function(){	
    getTickets();
})

function getTickets() {
	var request = new XMLHttpRequest;
	request.onreadystatechange = function() {
		if(this.readyState==4 && this.status==200){
			var jsonTickets = JSON.parse(this.responseText);
			for(i=0; i<jsonTickets.length; i++) {
				var status = jsonTickets[i].status;
				
				var ticket=document.createElement('div');
				ticket.className='ticket';

				ticket.appendChild(makeIdLabel(jsonTickets[i]));
				ticket.appendChild(makeStatusLabel(jsonTickets[i]));
				
				if(status=='Pending') {
					ticket.appendChild(makeAssignedLabel(jsonTickets[i]));
				}					
				if(status=='Solved' || status=='Unsolved') {
					ticket.appendChild(makeClosedLabel(jsonTickets[i]));
				}
				ticket.appendChild(makeIssueParagraph(jsonTickets[i]));
				
				document.getElementById('tickets').appendChild(ticket);
			}
		}
	}
	request.open('GET', '/helpdesk/user/my-tickets?ID=2')
	request.send();
}
	
function makeIdLabel(jsonTicket) {
	var text=document.createTextNode('#'+jsonTicket.id);
	var h5=document.createElement('h5');
	h5.className=jsonTicket.status.toLowerCase();
	h5.appendChild(text);
	return h5;
}

function makeStatusLabel(jsonTicket) {
	var text=document.createTextNode(jsonTicket.status);
	var h5=document.createElement('h5');
	h5.className=jsonTicket.status.toLowerCase();
	h5.appendChild(text);
	return h5;
}

function makeAssignedLabel(jsonTicket) {
	var assignedTo = jsonTicket.assignedTo;
	var text = document.createTextNode(assignedTo);
	var a = document.createElement('a');
	a.className=jsonTicket.status.toLowerCase();
	a.setAttribute('href', 'mailto:'+assignedTo);
	a.appendChild(text);
	var h5 = document.createElement('h5');
	h5.className=jsonTicket.status.toLowerCase();
	h5.appendChild(document.createTextNode('Assigned to: '));
	h5.appendChild(a);
	return h5;
}

function makeClosedLabel(jsonTicket) {
	var closedBy = jsonTicket.closedBy;
	var text = document.createTextNode(closedBy);
	var a = document.createElement('a');
	a.className=jsonTicket.status.toLowerCase();
	a.setAttribute('href', 'mailto:'+closedBy);
	a.appendChild(text);
	var h5 = document.createElement('h5');
	h5.className=jsonTicket.status.toLowerCase();
	h5.appendChild(document.createTextNode('Closed by: '));
	h5.appendChild(a);
	return h5;
}

function makeIssueParagraph(jsonTicket) {
	var text = document.createTextNode(jsonTicket.issue);
	var p = document.createElement('p');
	p.appendChild(text);
	return p;
}
