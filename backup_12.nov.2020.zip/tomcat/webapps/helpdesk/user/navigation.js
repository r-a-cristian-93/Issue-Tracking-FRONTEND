document.addEventListener("DOMContentLoaded", function(){	
    getHTML('top', '../user/navigation.html');
})


function loadMenuItems() {
	document.getElementById('menu');
	
}
