function openNewTicket() {
	var issue = document.newticket.issue.value;
	
	if(issue) {
		var request = new XMLHttpRequest();
		request.onreadystatechange = function() {
			if(this.readyState==4 && this.status==200) {
				var response = JSON.parse(request.responseText);
				document.getElementById('response').innerHTML = response;
			}
		}
		request.open('POST', 'newticket');
		request.send(issue);		
	}
	else {
		document.getElementById('response').innerHTML = 'The message can not be empty.';
	}	
}
