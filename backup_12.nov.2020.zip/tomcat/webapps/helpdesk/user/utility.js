function getHTML(elementId, pageName) {
	var request = new XMLHttpRequest();
	request.onreadystatechange = function() {
		if(this.readyState==4 && this.status==200) {
			document.getElementById(elementId).innerHTML=this.responseText;
			getMenu();
		}
	}
	request.open('GET', pageName);
	request.send();
}

function getMenu() {
	var request = new XMLHttpRequest();
	request.onreadystatechange = function(){
		if(this.readyState==4 && this.status==200) {
			var menuItems = JSON.parse(this.responseText);

			document.getElementById('welcome-user').innerHTML="Hello, " + menuItems[0].name;
			
			for(i=1; i<menuItems.length; i++) {
				var name = menuItems[i].name;
				var url = menuItems[i].url;
				var menuItem = document.createElement('a');
				var nameNode = document.createTextNode(name);
				menuItem.setAttribute('href', url);
				menuItem.appendChild(nameNode);
				document.getElementById('menu').appendChild(menuItem);				
			}
		}
	}
	request.open('GET', '/helpdesk/user/navigation');
	request.send();
}
