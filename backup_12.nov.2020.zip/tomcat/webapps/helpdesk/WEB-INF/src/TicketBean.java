public class TicketBean {
	private int id;
	private String openedBy;
	private String closedBy;
	private String assignedTo;
	private String status;
	private String issue;
	
	public TicketBean() {}
	
	public TicketBean setId(int id) {
		this.id=id;
		return this;
	}
	public TicketBean setOpenedBy(String openedBy) {
		this.openedBy=openedBy;
		return this;
	}
	public TicketBean setClosedBy(String closedBy) {
		this.closedBy=closedBy;
		return this;
	}
	public TicketBean setAssignedTo(String assignedTo) {
		this.assignedTo=assignedTo;
		return this;
	}
	public TicketBean setStatus(String status) {
		this.status=status;
		return this;
	}
	public TicketBean setIssue(String issue) {
		this.issue=issue;
		return this;
	}
	
	public int getId() {
		return id;
	}
	public String getOpenedBy() {
		return openedBy;
	}
	public String getClosedBy() {
		return closedBy;
	}
	public String getStatus() {
		return status;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public String getIssue() {
		return issue;
	}
}
