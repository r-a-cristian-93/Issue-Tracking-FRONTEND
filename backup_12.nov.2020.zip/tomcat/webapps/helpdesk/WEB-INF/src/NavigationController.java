import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import org.json.*;

@WebServlet(value="/user/navigation")
public class NavigationController extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		UserBean userBean = (UserBean) request.getAttribute("user_bean");
		
		JSONArray navigation = new JSONArray();
		navigation.put(new JSONObject(new NavigationItemBean().setState(userBean.getEmail(), "#")));					 //TO DO: decide where to point
		navigation.put(new JSONObject(new NavigationItemBean().setState("NEW TICKET", "../user/new-ticket.html")));
		navigation.put(new JSONObject(new NavigationItemBean().setState("MY TICKETS", "../user/my-tickets.html")));
		if(userBean.getRole().equals("Owner")) {
			navigation.put(new JSONObject(new NavigationItemBean().setState("REGISTER", "../owner/register.html")));
		}
		response.setContentType("application/json");
		response.getWriter().print(navigation);
	}
}
