import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.auth0.jwt.*;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.*;
import com.auth0.jwt.interfaces.*;

public class Helper {
	public static Connection getConnection() throws SQLException{
		String url="jdbc:mysql://hd_database:3306/helpdesk";
		Connection connection = DriverManager.getConnection(url, "root", "root");
		return connection;
	}
	
	public static Statement getStatement() throws SQLException{
		return Helper.getConnection().createStatement();
	}
	
	public static ResultSet sqlQuery(String sql) throws SQLException{
		return Helper.getStatement().executeQuery(sql);
	}
	
	public static int sqlUpdate(String sql) throws SQLException{
		return Helper.getStatement().executeUpdate(sql);
	}
	
	public static String randomPassword(int length) {
		StringBuilder password = new StringBuilder();
		Random generator = new Random();
		for (int i=0; i<length; i++) {
			char c =  (char) (generator.nextInt(93) + 33);
			password.append(c);
		}
		return password.toString();
	}
	
	public static String getBody(HttpServletRequest request) {
		StringBuilder body = new StringBuilder();
		try {
			BufferedReader reader = request.getReader();
			String line = null;
			while((line = reader.readLine()) != null) {
				body.append(line);
			}
			return new String(body);
		}
		catch (Exception e) {
			return null;
		}
	}
	
	public static ArrayList<TicketBean> getTickets(int userId) throws SQLException {
		ArrayList<TicketBean> tickets = new ArrayList<>();
		String sql = "SELECT x.ID, x.status, x.issue, x.closed_by, users.email AS assigned_to "+
						"FROM (SELECT tickets.ID, tickets.status, tickets.issue, tickets.assigned_to, users.email AS closed_by "+
								"FROM tickets "+
								"LEFT JOIN users "+
								"ON tickets.closed_by=users.ID "+
								"WHERE tickets.opened_by="+userId+") AS x "+ 
						"LEFT JOIN users "+
						"ON x.assigned_to=users.ID;";
							
		ResultSet resultSet = Helper.sqlQuery(sql);
		while(resultSet.next()){
			int id = resultSet.getInt("ID");
			String status = resultSet.getString("status");
			String assignedTo = resultSet.getString("assigned_to");
			String closedBy = resultSet.getString("closed_by");
			String issue = resultSet.getString("issue");
			tickets.add(new TicketBean().setId(id)
										.setStatus(status)
										.setAssignedTo(assignedTo)
										.setClosedBy(closedBy)
										.setIssue(issue));
		}
		return tickets;
	}		

	public static String getToken(HttpServletRequest request) {
		String token = null;		
		try {
			Cookie[] reqCookies = request.getCookies();
			for (int i=0; i<reqCookies.length; i++) {
				if(reqCookies[i].getName().equals("JWT")) {
					token = reqCookies[i].getValue();
				}
			}				
		}
		catch(NullPointerException e) {}
		return token;
	}
	
	public static DecodedJWT verifyJwt(HttpServletRequest request) {
		String token = Helper.getToken(request);
		DecodedJWT jwt = null;
	
		try {
			String key = "secret";
			Algorithm algorithm = Algorithm.HMAC256(key);
			JWTVerifier verifier = JWT.require(algorithm)
				.withIssuer("helpdesk.com")
				.build();
			 jwt = verifier.verify(token);
		} 
		catch (Exception e){}
		
		return jwt;
	}
		
}	
